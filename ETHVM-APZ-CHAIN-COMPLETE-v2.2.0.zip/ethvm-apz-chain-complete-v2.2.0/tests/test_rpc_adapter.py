import asyncio
import pytest
from app import rpc as rpc_module

class FakeResponse:
    def __init__(self, payload):
        self.payload = payload
    def raise_for_status(self):
        return None
    def json(self):
        return self.payload

class FakeClient:
    def __init__(self, response):
        self.response = response
    async def __aenter__(self):
        return self
    async def __aexit__(self, *args):
        return False
    async def post(self, url, json):
        assert url == "http://geth:8545"
        assert json["jsonrpc"] == "2.0"
        return FakeResponse(self.response)

def test_rpc_returns_result(monkeypatch):
    monkeypatch.setattr(rpc_module.settings, "rpc_url", "http://geth:8545")
    monkeypatch.setattr(rpc_module.httpx, "AsyncClient", lambda **kwargs: FakeClient({
        "jsonrpc": "2.0", "id": 1, "result": "0x539"
    }))
    assert asyncio.run(rpc_module.rpc("eth_chainId")) == "0x539"

def test_rpc_rejects_invalid_envelope(monkeypatch):
    monkeypatch.setattr(rpc_module.settings, "rpc_url", "http://geth:8545")
    monkeypatch.setattr(rpc_module.httpx, "AsyncClient", lambda **kwargs: FakeClient({"result": "0x1"}))
    with pytest.raises(rpc_module.RPCFailure, match="Malformed JSON-RPC envelope"):
        asyncio.run(rpc_module.rpc("eth_chainId"))

def test_rpc_surfaces_rpc_error_safely(monkeypatch):
    monkeypatch.setattr(rpc_module.settings, "rpc_url", "http://geth:8545")
    monkeypatch.setattr(rpc_module.httpx, "AsyncClient", lambda **kwargs: FakeClient({
        "jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "method not found"}
    }))
    with pytest.raises(rpc_module.RPCFailure, match="method not found"):
        asyncio.run(rpc_module.rpc("not_a_method"))

def test_node_status_verifies_official_identity_only_when_all_values_match(monkeypatch):
    async def fake_rpc(method, params=None):
        values = {
            "eth_chainId": "0x539",
            "net_version": "1337",
            "eth_blockNumber": "0x2a",
            "eth_getBlockByNumber": {"hash": "0x" + "ab" * 32},
            "eth_syncing": False,
            "net_peerCount": "0x3",
            "web3_clientVersion": "Geth/test",
            "eth_gasPrice": "0x1",
            "txpool_status": {"pending": "0x2", "queued": "0x1"},
        }
        return values[method]
    monkeypatch.setattr(rpc_module, "rpc", fake_rpc)
    monkeypatch.setattr(rpc_module.settings, "expected_chain_id", 1337)
    monkeypatch.setattr(rpc_module.settings, "expected_network_id", 1337)
    monkeypatch.setattr(rpc_module.settings, "expected_genesis_block_hash", "0x" + "ab" * 32)
    status = asyncio.run(rpc_module.node_status())
    assert status["network_identity_verified"] is True
    assert status["chain_id"] == 1337
    assert status["network_id"] == 1337


def test_node_status_does_not_verify_identity_on_genesis_mismatch(monkeypatch):
    async def fake_rpc(method, params=None):
        values = {
            "eth_chainId": "0x539", "net_version": "1337", "eth_blockNumber": "0x0",
            "eth_getBlockByNumber": {"hash": "0x" + "cd" * 32}, "eth_syncing": False,
            "net_peerCount": "0x0", "web3_clientVersion": "Geth/test",
            "eth_gasPrice": "0x1", "txpool_status": {},
        }
        return values[method]
    monkeypatch.setattr(rpc_module, "rpc", fake_rpc)
    monkeypatch.setattr(rpc_module.settings, "expected_chain_id", 1337)
    monkeypatch.setattr(rpc_module.settings, "expected_network_id", 1337)
    monkeypatch.setattr(rpc_module.settings, "expected_genesis_block_hash", "0x" + "ab" * 32)
    status = asyncio.run(rpc_module.node_status())
    assert status["network_identity_verified"] is False
