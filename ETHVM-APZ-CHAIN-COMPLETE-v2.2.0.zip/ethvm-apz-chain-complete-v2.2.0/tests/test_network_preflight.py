import hashlib
import importlib.util
import json
from pathlib import Path
import pytest

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "validate_apz_network.py"
spec = importlib.util.spec_from_file_location("validate_apz_network", SCRIPT)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

def setup_network(tmp_path, monkeypatch):
    root = tmp_path
    genesis = root / "network/apz/genesis.json"
    lighthouse = root / "network/apz/lighthouse"
    secrets = root / "secrets"
    lighthouse.mkdir(parents=True)
    secrets.mkdir()
    raw = json.dumps({"config": {"chainId": 98765}, "nonce": "0x0", "timestamp": "0x0",
                      "extraData": "0x", "gasLimit": "0x1c9c380", "difficulty": "0x0", "alloc": {}}).encode()
    genesis.write_bytes(raw)
    (lighthouse / "config.yaml").write_text("CONFIG_NAME: apz\n")
    (lighthouse / "genesis.ssz").write_bytes(b"official-consensus-genesis")
    (lighthouse / "boot_enr.yaml").write_text("- enr: official-peer\n")
    (secrets / "jwt.hex").write_text("ab" * 32 + "\n")
    monkeypatch.setattr(module, "ROOT", root)
    monkeypatch.setattr(module, "GENESIS", genesis)
    monkeypatch.setattr(module, "LIGHTHOUSE_DIR", lighthouse)
    monkeypatch.setattr(module, "JWT_FILE", secrets / "jwt.hex")
    monkeypatch.setenv("APZ_CHAIN_ID", "98765")
    monkeypatch.setenv("APZ_NETWORK_ID", "98765")
    monkeypatch.setenv("APZ_GENESIS_SHA256", hashlib.sha256(raw).hexdigest())
    monkeypatch.setenv("APZ_GENESIS_BLOCK_HASH", "0x" + "12" * 32)
    monkeypatch.setenv("APZ_CONSENSUS_TYPE", "ethereum-pos-engine-api")
    monkeypatch.setenv("APZ_CONSENSUS_GENESIS_SHA256", hashlib.sha256(b"official-consensus-genesis").hexdigest())

def test_preflight_accepts_complete_operator_supplied_artifacts(tmp_path, monkeypatch, capsys):
    setup_network(tmp_path, monkeypatch)
    module.main()
    assert "APZ network preflight: PASS" in capsys.readouterr().out

def test_preflight_rejects_genesis_chain_id_mismatch(tmp_path, monkeypatch):
    setup_network(tmp_path, monkeypatch)
    monkeypatch.setenv("APZ_CHAIN_ID", "1")
    with pytest.raises(SystemExit) as exc:
        module.main()
    assert exc.value.code == 2

def test_preflight_rejects_consensus_genesis_checksum_mismatch(tmp_path, monkeypatch):
    setup_network(tmp_path, monkeypatch)
    monkeypatch.setenv("APZ_CONSENSUS_GENESIS_SHA256", "0" * 64)
    with pytest.raises(SystemExit) as exc:
        module.main()
    assert exc.value.code == 2
