import os
os.environ.setdefault("ADMIN_PASSWORD", "test-password")
os.environ.setdefault("JWT_SECRET", "test-secret-that-is-at-least-32-characters-long")
os.environ.setdefault("AUDIT_LOG_PATH", "/tmp/ethvm-apz-test-audit.jsonl")

from fastapi.testclient import TestClient
from app.main import app
import app.main as main_module

client = TestClient(app)

def login_headers():
    r = client.post("/api/v1/auth/login", json={"username": "admin", "password": "test-password"})
    assert r.status_code == 200
    return {"Authorization": f"Bearer {r.json()['access_token']}"}

def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["version"] == "2.2.0"

def test_readiness_fails_when_execution_client_unavailable(monkeypatch):
    async def fake_readiness():
        return {"ready": False, "execution": {"connected": False}}
    monkeypatch.setattr(main_module, "readiness", fake_readiness)
    assert client.get("/ready").status_code == 503

def test_dashboard_requires_auth():
    assert client.get("/api/v1/dashboard").status_code == 401

def test_login_and_dashboard(monkeypatch):
    async def fake_node_status():
        return {"connected": False, "client_role": "execution"}
    monkeypatch.setattr(main_module, "node_status", fake_node_status)
    d = client.get("/api/v1/dashboard", headers=login_headers())
    assert d.status_code == 200
    assert d.json()["validator"]["status"] == "not_configured"

def test_invalid_login():
    r = client.post("/api/v1/auth/login", json={"username": "admin", "password": "wrong"})
    assert r.status_code == 401

def test_rpc_read_requires_auth():
    assert client.post("/api/v1/rpc/read", json={"method": "eth_chainId"}).status_code == 401

def test_rpc_read_rejects_write_methods():
    r = client.post("/api/v1/rpc/read", headers=login_headers(),
                    json={"method": "eth_sendRawTransaction", "params": ["0x00"]})
    assert r.status_code == 400
    assert "read-only" in r.json()["detail"]

def test_rpc_read_forwards_allowlisted_method(monkeypatch):
    async def fake_read_rpc(method, params):
        assert method == "eth_chainId"
        assert params == []
        return "0x539"
    monkeypatch.setattr(main_module, "read_rpc", fake_read_rpc)
    r = client.post("/api/v1/rpc/read", headers=login_headers(), json={"method": "eth_chainId"})
    assert r.status_code == 200
    assert r.json()["result"] == "0x539"

def test_consensus_status_requires_auth():
    assert client.get("/api/v1/consensus/status").status_code == 401
