import asyncio
from app import consensus as consensus_module

class FakeResponse:
    def raise_for_status(self):
        return None
    def json(self):
        return {"data": {"is_syncing": False, "is_optimistic": False,
                         "el_offline": False, "head_slot": "123", "sync_distance": "0"}}

class FakeClient:
    def __init__(self, *args, **kwargs):
        pass
    async def __aenter__(self):
        return self
    async def __aexit__(self, *args):
        return False
    async def get(self, url):
        assert url == "http://consensus:5052/eth/v1/node/syncing"
        return FakeResponse()

def test_consensus_not_configured(monkeypatch):
    monkeypatch.setattr(consensus_module.settings, "consensus_api_url", "")
    result = asyncio.run(consensus_module.consensus_status())
    assert result["status"] == "not_configured"

def test_consensus_beacon_api_status(monkeypatch):
    monkeypatch.setattr(consensus_module.settings, "consensus_api_url", "http://consensus:5052")
    monkeypatch.setattr(consensus_module.httpx, "AsyncClient", FakeClient)
    result = asyncio.run(consensus_module.consensus_status())
    assert result["connected"] is True
    assert result["is_syncing"] is False
    assert result["head_slot"] == "123"
