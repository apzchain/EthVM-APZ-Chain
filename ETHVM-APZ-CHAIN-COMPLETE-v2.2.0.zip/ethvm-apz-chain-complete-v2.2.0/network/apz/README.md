# Official APZ network artifacts

This directory intentionally contains no generated or sample Genesis files.

Place the official execution client genesis at `genesis.json`. Place the official Lighthouse-compatible consensus artifacts in `lighthouse/`:

- `config.yaml`
- `genesis.ssz`
- `boot_enr.yaml`

Obtain each file and its checksum from an authoritative APZ network release, with verifiable publisher provenance. Never substitute an Ethereum Mainnet/Testnet file, the local Geth Devnet values, or an unofficial third-party sample.
