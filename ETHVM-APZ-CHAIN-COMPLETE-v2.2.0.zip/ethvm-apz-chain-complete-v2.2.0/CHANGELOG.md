# Changelog

## 2.2.0 - 2026-11-24

- Added a separate APZ deployment Compose file that initializes Geth from an operator-supplied official execution Genesis.
- Added authenticated Engine API wiring (port 8551, shared 32-byte JWT) for an explicitly conditional Lighthouse consensus profile.
- Added fail-closed preflight for official Chain ID, Network ID, execution Genesis checksum/hash, consensus Genesis checksum, Lighthouse config and boot ENRs.
- Added Beacon API syncing telemetry to the management API and dashboard.
- Added runtime network identity verification against Chain ID, Network ID and genesis block hash.
- Added opt-in Lighthouse validator service profile without generating or bundling validator keys.
- Preserved the local `--dev` stack as a separate development-only profile.
- Added tests for identity matching, Beacon API status and network-artifact preflight.

## 2.1.0 - 2026-11-24

- Added the Geth execution adapter, authenticated management API and local development stack.
- Explicitly marked APZ Mainnet identity and validator status as unconfigured.
