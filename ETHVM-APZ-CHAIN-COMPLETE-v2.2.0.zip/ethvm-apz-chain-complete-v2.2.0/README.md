# EthVM-APZ Chain Complete 2.2.0

A reproducible Geth execution integration with a conditional Lighthouse consensus/validator deployment profile. The APZ profile is deliberately fail-closed: it cannot start until the operator supplies the exact official network artifacts and values.

## Architecture

- **Execution:** upstream Geth `ethereum/client-go:v1.17.10`; EVM execution, transaction pool, state and execution payload validation.
- **Consensus candidate:** Lighthouse `sigp/lighthouse:v8.3.3`; connected to Geth through the authenticated Engine API and a shared 256-bit JWT secret.
- **Validator:** optional Compose profile. It does not generate or include validator keys. Keys must be imported by the operator and kept under slashing protection.
- **Management API:** FastAPI with read-only Geth JSON-RPC, Beacon API sync telemetry, and runtime network identity checks.
- **Android:** remote management client only; it does not run Geth, Lighthouse or a validator on the phone.

The Lighthouse deployment is appropriate only if APZ's official protocol is Ethereum PoS and explicitly supports the Engine API and Lighthouse custom-network format. If APZ uses a different consensus protocol (e.g. QBFT, Clique, Tendermint or a proprietary BFT), do not start this profile; the matching consensus implementation must be integrated instead.

## Network identity: no invented parameters

The default `docker-compose.yml` remains a local Geth development chain (`--dev`, local-only). It is not APZ Mainnet. The APZ-specific deployment is `docker-compose.apz.yml`, which initializes a separate database from an operator-supplied official Genesis.

Required artifacts and values:

| Input | Required value/source |
|---|---|
| `network/apz/genesis.json` | Official Geth execution genesis file |
| `APZ_CHAIN_ID` | Official decimal chain ID; must match `genesis.json` `config.chainId` |
| `APZ_NETWORK_ID` | Official P2P network ID; a separate value from Chain ID |
| `APZ_GENESIS_SHA256` | SHA-256 of the exact execution genesis file bytes |
| `APZ_GENESIS_BLOCK_HASH` | Official execution genesis block hash (`0x` + 64 hex chars) |
| `network/apz/lighthouse/config.yaml` | Official Lighthouse-compatible consensus config |
| `network/apz/lighthouse/genesis.ssz` | Official consensus genesis state |
| `network/apz/lighthouse/boot_enr.yaml` | Official consensus boot ENRs |
| `APZ_CONSENSUS_GENESIS_SHA256` | SHA-256 of the exact `genesis.ssz` bytes |
| `APZ_CONSENSUS_TYPE` | Must be `ethereum-pos-engine-api` only if APZ's official spec confirms it |
| `secrets/jwt.hex` | Generated shared Engine API secret (32 bytes, hex) |

The preflight checks file presence, SHA-256 checksums, JSON structure and chain ID. At runtime the API compares the live Geth Chain ID, Network ID and genesis block hash with the configured official values. These checks do not prove the source publisher is authoritative or prove the execution and consensus genesis are semantically paired; obtain signed/provenance-verified artifacts from APZ maintainers.

## APZ deployment

1. Copy `.env.example` to `.env`.
2. Fill the required APZ values only from the official APZ network release.
3. Place the execution genesis and Lighthouse consensus artifacts in the paths above.
4. Generate the shared Engine API secret:

   ```bash
   python3 scripts/create_engine_jwt.py
   ```

5. Run fail-closed preflight and start:

   ```bash
   python3 scripts/validate_apz_network.py
   ./scripts/start_apz.sh
   ```

6. Check services and API:

   ```bash
   docker compose --env-file .env -f docker-compose.apz.yml ps
   curl -s http://127.0.0.1:8080/health
   ```

The APZ compose starts Geth with `geth init` using the supplied Genesis, enables the private authenticated Engine API on port 8551, and starts Lighthouse against the supplied custom-network directory. The same JWT file is mounted read-only into both clients. Port 8551 is not published to the host.

## Validator activation (manual and opt-in)

Validator keys are not created, included, or automatically activated. First verify APZ PoS rules, deposit/activation process, approved validator client, fee recipient, and slashing-protection requirements. Import authorized keys into the persistent Lighthouse validator datadir using Lighthouse's supported account import workflow; do not store raw keys in source control. Then start only the optional validator service:

```bash
docker compose --env-file .env -f docker-compose.apz.yml --profile validator up -d validator
```

Do not run the same signing keys on two active machines. The API intentionally continues to report validator status as `not_configured` until an independently verified validator-status integration is implemented; a running container is not proof of validator duties or activation.

## Existing development stack

For local UI/API development only:

```bash
cp .env.example .env
# Set ADMIN_PASSWORD and JWT_SECRET before startup.
docker compose up --build -d
```

This uses Geth `--dev` and must never be confused with APZ Mainnet/Testnet.

## API

- `GET /health` — management API liveness
- `GET /ready` — Geth readiness; also requires configured Beacon API reachability in APZ profile
- `POST /api/v1/auth/login`
- `GET /api/v1/auth/me`
- `GET /api/v1/dashboard` — execution + consensus status and validator boundary
- `GET /api/v1/node/status`
- `GET /api/v1/consensus/status` — Beacon API syncing telemetry
- `POST /api/v1/rpc/read` — authenticated read-only JSON-RPC allowlist
- `GET /api/v1/validator/status` — deliberately not configured until validator duties can be verified
- `GET /api/v1/audit/recent` — admin role
- `/docs` — OpenAPI documentation

Network identity becomes `verified` only when all three live execution values match `APZ_CHAIN_ID`, `APZ_NETWORK_ID`, and `APZ_GENESIS_BLOCK_HASH`.

## Tests and build checks

```bash
pip install -r requirements-dev.txt
pytest -q
python -m compileall -q app scripts tests
```

The tests mock RPC/Beacon responses and exercise fail-closed preflight. They do not replace a real APZ network smoke test. Docker Engine/Compose and official APZ network artifacts are required to verify container startup and cross-client sync.

## Android

Open `android/` in Android Studio with JDK 17. The Android app is an operations client and cannot host the server-side execution/consensus clients. This archive does not include a signed APK/AAB.

## Security

- Keep Geth HTTP RPC and Engine API private. Never publish port 8551.
- Keep the JWT secret and validator keys out of source control.
- Use new data volumes when changing genesis/network identity.
- Use TLS and an authenticated reverse proxy before exposing the management API remotely.
- Read `documentation/security/THREAT_MODEL.md` before deployment.

## License

MIT for this integration package. Geth and Lighthouse are separate upstream dependencies under their respective licenses; review upstream notices before redistribution.
