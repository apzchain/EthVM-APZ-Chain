#!/usr/bin/env sh
set -eu
if [ ! -f .env ]; then cp .env.example .env; echo "Edit .env credentials then rerun."; exit 0; fi
docker compose up --build -d
echo "Dashboard: http://localhost:8080"
