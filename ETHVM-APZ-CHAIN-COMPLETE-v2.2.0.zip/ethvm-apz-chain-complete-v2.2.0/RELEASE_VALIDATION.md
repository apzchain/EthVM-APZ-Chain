# 2.2.0 validation report

Validated in the build environment on 2026-11-24:

- `pytest -q`: **19 passed**.
- `python -m compileall -q app scripts tests`: passed.
- YAML parsing of `docker-compose.yml` and `docker-compose.apz.yml`: passed.
- APZ preflight unit tests: complete official-artifact inputs pass; wrong execution Chain ID and wrong consensus Genesis checksum fail closed.

Not validated / intentionally blocked:

- Docker Engine and Docker Compose were not installed in the build environment; no container image pull, `geth init`, Lighthouse boot, or live Engine API handshake was run.
- The supplied 2.0/2.1 project archives did not include official APZ execution Genesis, consensus genesis/config, boot ENRs, chain/network IDs, or a signed APZ consensus specification.
- No validator key was generated/imported and no validator was activated.
- The Lighthouse profile is conditional on APZ officially confirming Ethereum PoS + Engine API compatibility. If APZ consensus is another protocol, this profile must not be used.

Therefore this package is an implemented, tested integration path with strict gates; it is **not evidence that APZ Mainnet has been connected or that a validator is active**.
