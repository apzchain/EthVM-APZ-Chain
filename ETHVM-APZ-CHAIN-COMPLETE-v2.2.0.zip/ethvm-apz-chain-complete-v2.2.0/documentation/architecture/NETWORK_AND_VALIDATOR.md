# APZ execution, consensus and validator architecture (2.2)

## What this release implements

- Geth remains the execution client and the only EVM/state-transition engine.
- `docker-compose.apz.yml` is a separate, fail-closed APZ deployment profile. It initializes Geth from the operator-supplied `network/apz/genesis.json`; it does not use `--dev` and does not reuse the development database.
- Geth exposes the user JSON-RPC only on the private Compose network. Its authenticated Engine API is on port 8551, also private, and uses the shared 32-byte JWT secret.
- A Lighthouse Beacon Node service is wired to `http://geth-apz:8551` using that JWT secret. It reads a custom network directory containing `config.yaml`, `genesis.ssz` and `boot_enr.yaml`.
- The management API reads the Beacon API syncing endpoint and reports execution and consensus status separately.
- Runtime network identity is marked verified only when the live execution client matches all three operator-supplied official values: chain ID, network ID and genesis block hash.
- A separate opt-in `validator` Compose profile is present. It does not generate keys. Validator key import, fee-recipient policy and slashing-protection review remain operator-controlled.

## Critical compatibility gate

The Lighthouse profile is valid only if APZ's officially published consensus specification confirms an Ethereum Proof-of-Stake consensus protocol compatible with the Engine API and Lighthouse's custom-network format. This repository contains no official APZ consensus specification. If APZ uses Clique, QBFT, Tendermint, a proprietary BFT protocol, or another non-Engine-API consensus design, do not start this Lighthouse profile; implement the matching consensus client/adapter instead. Geth alone cannot determine or supply APZ consensus rules.

## Required official artifacts (never invent these)

1. `network/apz/genesis.json`: official Geth execution genesis.
2. `APZ_CHAIN_ID`: decimal chain ID matching `genesis.json` `config.chainId`.
3. `APZ_NETWORK_ID`: official execution P2P network ID. It is a separate value and must not be assumed equal to chain ID.
4. `APZ_GENESIS_SHA256`: SHA-256 of the exact distributed `genesis.json` file bytes.
5. `APZ_GENESIS_BLOCK_HASH`: official genesis execution block hash (`0x` + 64 hex characters), checked against live `eth_getBlockByNumber("0x0", false)`.
6. `network/apz/lighthouse/config.yaml`, `genesis.ssz`, `boot_enr.yaml`: official Lighthouse-compatible consensus network artifacts.
7. `APZ_CONSENSUS_GENESIS_SHA256`: SHA-256 of the exact `genesis.ssz` file bytes.
8. `APZ_CONSENSUS_TYPE=ethereum-pos-engine-api`: set only when the official APZ specification confirms this consensus interface.
9. A generated Engine API JWT file at `secrets/jwt.hex`. The same file is mounted read-only into Geth and Lighthouse.

The preflight verifies presence, format, file checksums and execution genesis chain ID. It does not prove that the source is authoritative, nor cryptographically prove that the execution and consensus genesis artifacts describe the same network. Obtain these files and their published checksums from the APZ network maintainers and independently verify their signatures/provenance.

## Start the APZ profile

```bash
cp .env.example .env
# Fill the APZ_* values from the official APZ release; do not copy values from Devnet.
# Place official genesis.json and Lighthouse network files in the paths above.
python3 scripts/create_engine_jwt.py
python3 scripts/validate_apz_network.py
./scripts/start_apz.sh
```

The preflight intentionally exits non-zero until every required official artifact and value is supplied. Do not bypass it. The Compose file then runs `geth init` against the supplied genesis and starts Geth with the separate Engine API listener. Consensus connects to that listener using JWT authentication.

## Validator activation

The validator service is opt-in and is not a key generator. Before starting it:

- confirm the APZ protocol actually uses Ethereum PoS and Lighthouse is an approved client;
- obtain validator keys from the authorized key-generation/deposit process;
- import keys into the persistent Lighthouse validator data directory using Lighthouse's supported account import workflow;
- configure the official fee recipient and confirm activation/eligibility rules;
- establish and back up slashing-protection data; never run the same validator signing keys on two active machines;
- verify the beacon node is synced and the execution client is online.

Import only the authorized validator keystores from the operator-controlled import directory (the default is `secrets/validator-import/`):

```bash
docker compose --env-file .env -f docker-compose.apz.yml --profile validator run --rm \
  --entrypoint lighthouse validator \
  --testnet-dir=/network-config --datadir=/validator-data \
  account validator import --directory=/validator-import
```

Then start the optional client with `docker compose --env-file .env -f docker-compose.apz.yml --profile validator up -d validator`. This does not itself prove validator activation; verify duties and status through the approved consensus client and network explorer.

## Security

- Never publish port 8551. It is an authenticated inter-client control plane, not a public RPC API.
- Keep `secrets/jwt.hex` and validator key material out of source control and backups that are not encrypted.
- Do not expose Geth HTTP RPC or Lighthouse Beacon API publicly without an explicit hardened reverse-proxy and access-control design.
- Use separate persistent volumes for dev and APZ data. Changing genesis requires a new data directory/volume.
- A wrong consensus network configuration can cause permanent divergence or validator slashing. Stop rather than guessing.

## References

- Geth consensus-client connection: https://geth.ethereum.org/docs/getting-started/consensus-clients
- Geth RPC and Engine API: https://geth.ethereum.org/docs/interacting-with-geth/rpc
- Engine API JWT authentication: https://github.com/ethereum/execution-apis/blob/main/src/engine/authentication.md
- Ethereum node architecture: https://ethereum.org/developers/docs/nodes-and-clients/node-architecture/
- Lighthouse Docker: https://lighthouse-book.sigmaprime.io/installation_docker.html
- Lighthouse custom network directory: https://lighthouse-book.sigmaprime.io/help_bn.html
