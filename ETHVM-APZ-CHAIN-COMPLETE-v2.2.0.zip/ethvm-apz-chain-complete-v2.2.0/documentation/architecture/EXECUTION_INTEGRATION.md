# Execution integration (2.2)

Geth is the execution client. The default `docker-compose.yml` remains a local developer stack (`--dev`) and must not be used as APZ Mainnet. The APZ-specific `docker-compose.apz.yml` initializes a separate Geth datadir from an operator-provided official genesis file.

The APZ profile enables:

- private user JSON-RPC on the Compose network (`8545`);
- private authenticated Engine API (`8551`) for the consensus client;
- shared 256-bit JWT secret mounted read-only into both clients;
- a Lighthouse Beacon Node profile, conditional on APZ's official confirmation of Ethereum PoS / Engine API compatibility;
- a Beacon API status adapter for sync telemetry;
- runtime chain identity checks using official chain ID, network ID and genesis block hash.

The management API never forwards Engine API calls. The Engine API is a control-plane protocol used by the consensus client and must not be exposed to wallets or the public internet.
