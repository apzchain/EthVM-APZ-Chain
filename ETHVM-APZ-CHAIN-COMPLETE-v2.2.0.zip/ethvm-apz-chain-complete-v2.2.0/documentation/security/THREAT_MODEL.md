# Threat model and security boundaries

## Assets
Administrator credentials, bearer tokens, node RPC availability, operational audit records,
and infrastructure configuration.

## Trust boundaries
The browser/mobile WebView is an untrusted client. The API is a separate service. Geth JSON-RPC
is internal-only on the Docker network and is not published to the host. The API container is
not granted the Docker socket or host control.

## Implemented baseline controls
- PBKDF2-HMAC-SHA256 password hashing with per-password random salt.
- HMAC-SHA256 signed bearer tokens with expiry.
- Protected dashboard and audit endpoints.
- Failed/successful login audit events.
- Geth RPC port not published to host.
- API port bound to localhost by default.
- CI tests and dependency audit workflow.

## Known limitations / production blockers
- Bootstrap single-admin account; no persistent user database, MFA, password reset, or account lockout.
- JWT secret rotation/revocation is not implemented.
- JSONL audit log is not tamper-evident.
- No reverse proxy/TLS configuration is bundled.
- CORS must be restricted to the exact deployed dashboard origin.
- Geth `--dev` is for local development only; it is not APZ Mainnet.
- Validator signing and consensus operations are deliberately absent.

## Production checklist
Use OIDC or another mature identity provider, MFA, RBAC persistence, rate limiting,
TLS, secrets manager, immutable audit storage, backups, image signing, SBOM generation,
vulnerability scanning, independent penetration testing, and documented incident response.
