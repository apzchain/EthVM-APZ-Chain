# Operations runbook

1. Copy `.env.example` to `.env` and replace the admin password and JWT secret.
2. Validate Compose syntax with `docker compose config`.
3. Start services using `docker compose up --build -d`.
4. Check `docker compose ps` and `docker compose logs --tail=100 geth api`.
5. Check liveness at `/health` and execution readiness at `/ready`.
6. Log in through the dashboard and inspect execution-node telemetry.
7. Stop with `docker compose down`; persistent local-dev data remains in the named volume.
8. To reset only the disposable local development chain, stop services and remove `geth_data` explicitly. This deletes its local chain data.

Do not expose the Geth RPC port or the management API directly to the public internet. Use a TLS reverse proxy, authentication, network restrictions, backups, and a secret manager for any remote deployment. This runbook does not authorize use as an APZ Mainnet validator.
