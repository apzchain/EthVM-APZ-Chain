"""Read-only Lighthouse Beacon API health integration."""
import httpx
from app.config import settings

async def consensus_status():
    if not settings.consensus_api_url:
        return {"configured": False, "connected": False, "status": "not_configured",
                "reason": "No APZ consensus API endpoint is configured."}
    url = settings.consensus_api_url.rstrip("/") + "/eth/v1/node/syncing"
    try:
        async with httpx.AsyncClient(timeout=settings.rpc_timeout_seconds) as client:
            response = await client.get(url)
            response.raise_for_status()
            payload = response.json()
        data = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(data, dict):
            raise ValueError("Malformed Beacon API syncing response")
        return {"configured": True, "connected": True, "status": "connected",
                "is_syncing": data.get("is_syncing"),
                "is_optimistic": data.get("is_optimistic"),
                "el_offline": data.get("el_offline"),
                "head_slot": data.get("head_slot"),
                "sync_distance": data.get("sync_distance")}
    except (httpx.HTTPError, ValueError) as exc:
        return {"configured": True, "connected": False, "status": "unreachable",
                "reason": str(exc)}
