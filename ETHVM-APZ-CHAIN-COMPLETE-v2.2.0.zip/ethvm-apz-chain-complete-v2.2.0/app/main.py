from fastapi import FastAPI, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from pathlib import Path
from app.config import settings
from app.security import password_hash, password_verify, issue_token, verify_token
from app.audit import audit, recent
from app.rpc import node_status, readiness, read_rpc, RPCFailure
from app.consensus import consensus_status

app = FastAPI(title="EthVM-APZ Management API", version="2.2.0")
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins,
                   allow_credentials=False, allow_methods=["GET", "POST"],
                   allow_headers=["Authorization", "Content-Type"])
bearer = HTTPBearer(auto_error=False)
_BOOTSTRAP_HASH = password_hash(settings.admin_password) if settings.admin_password else ""

class Login(BaseModel):
    username: str = Field(min_length=1, max_length=80)
    password: str = Field(min_length=1, max_length=256)

class ReadRPCRequest(BaseModel):
    method: str = Field(min_length=1, max_length=80)
    params: list = Field(default_factory=list, max_length=100)

def current_user(creds: HTTPAuthorizationCredentials | None = Depends(bearer)):
    if not creds:
        raise HTTPException(401, "Bearer token required")
    try:
        return verify_token(creds.credentials)
    except ValueError:
        raise HTTPException(401, "Invalid or expired token")

def require_admin(user=Depends(current_user)):
    if user["role"] != "admin":
        raise HTTPException(403, "Administrator role required")
    return user

@app.get("/health")
async def health():
    return {"status": "ok", "version": "2.2.0", "component": "management-api"}

@app.get("/ready")
async def ready():
    result = await readiness()
    consensus = await consensus_status() if settings.consensus_api_url else {"configured": False}
    result["consensus"] = consensus
    if not result["ready"] or (consensus.get("configured") and not consensus.get("connected")):
        raise HTTPException(503, result)
    return result

@app.post("/api/v1/auth/login")
async def login(body: Login):
    valid = (settings.admin_password and body.username == settings.admin_username
             and password_verify(body.password, _BOOTSTRAP_HASH))
    if not valid:
        audit("login_failed", body.username)
        raise HTTPException(401, "Invalid username or password")
    token = issue_token(body.username, "admin")
    audit("login_success", body.username)
    return {"access_token": token, "token_type": "bearer", "expires_in": settings.jwt_ttl_minutes * 60}

@app.get("/api/v1/auth/me")
async def me(user=Depends(current_user)):
    return {"username": user["sub"], "role": user["role"]}

@app.get("/api/v1/dashboard")
async def dashboard(user=Depends(current_user)):
    node = await node_status()
    consensus = await consensus_status()
    return {"network": settings.network_name, "node": node, "consensus": consensus,
            "validator": {"status": "not_configured",
                          "reason": "Validator keys and APZ consensus rules are not provisioned. Beacon connectivity alone does not activate a validator."},
            "authenticated_user": user["sub"]}

@app.get("/api/v1/node/status")
async def get_node_status(user=Depends(current_user)):
    return await node_status()

@app.post("/api/v1/rpc/read")
async def rpc_read(body: ReadRPCRequest, user=Depends(current_user)):
    try:
        result = await read_rpc(body.method, body.params)
        audit("rpc_read", user["sub"], {"method": body.method})
        return {"jsonrpc": "2.0", "method": body.method, "result": result}
    except RPCFailure as exc:
        raise HTTPException(400, str(exc))

@app.get("/api/v1/consensus/status")
async def get_consensus_status(user=Depends(current_user)):
    return await consensus_status()

@app.get("/api/v1/validator/status")
async def validator_status(user=Depends(current_user)):
    return {"status": "not_configured", "client": "none",
            "message": "Validator duties remain disabled until APZ PoS rules, approved validator keys, fee recipient and slashing-protection setup are verified."}

@app.get("/api/v1/audit/recent")
async def audit_recent(user=Depends(require_admin)):
    return {"events": recent()}

WEB = Path(__file__).resolve().parents[1] / "web"
app.mount("/assets", StaticFiles(directory=WEB), name="assets")

@app.get("/")
async def index():
    return FileResponse(WEB / "index.html")
