import json
from datetime import datetime, timezone
from pathlib import Path
from app.config import settings

def audit(event: str, actor: str = "system", details: dict | None = None):
    path = Path(settings.audit_log_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    entry = {"at": datetime.now(timezone.utc).isoformat(), "event": event,
             "actor": actor, "details": details or {}}
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry, ensure_ascii=False) + "\n")

def recent(limit: int = 50):
    path = Path(settings.audit_log_path)
    if not path.exists():
        return []
    rows = path.read_text(encoding="utf-8").splitlines()[-limit:]
    result = []
    for row in rows:
        try: result.append(json.loads(row))
        except json.JSONDecodeError: continue
    return list(reversed(result))
