import base64, hashlib, hmac, json, os, time
from app.config import settings

def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

def _unb64(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))

def password_hash(password: str, salt: bytes | None = None) -> str:
    salt = salt or os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 310_000)
    return f"pbkdf2_sha256${_b64(salt)}${_b64(digest)}"

def password_verify(password: str, encoded: str) -> bool:
    try:
        scheme, salt, expected = encoded.split("$", 2)
        if scheme != "pbkdf2_sha256":
            return False
        actual = password_hash(password, _unb64(salt)).split("$", 2)[2]
        return hmac.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False

def issue_token(subject: str, role: str = "admin") -> str:
    if len(settings.jwt_secret) < 32:
        raise RuntimeError("JWT_SECRET must contain at least 32 characters")
    header = _b64(json.dumps({"alg":"HS256","typ":"JWT"}, separators=(",",":")).encode())
    payload = _b64(json.dumps({"sub":subject,"role":role,"exp":int(time.time()) + settings.jwt_ttl_minutes*60}, separators=(",",":")).encode())
    signing = f"{header}.{payload}"
    signature = _b64(hmac.new(settings.jwt_secret.encode(), signing.encode(), hashlib.sha256).digest())
    return f"{signing}.{signature}"

def verify_token(token: str) -> dict:
    try:
        header, payload, signature = token.split(".")
        signing = f"{header}.{payload}"
        expected = _b64(hmac.new(settings.jwt_secret.encode(), signing.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(signature, expected):
            raise ValueError("invalid signature")
        claims = json.loads(_unb64(payload))
        if int(claims["exp"]) < int(time.time()):
            raise ValueError("expired")
        if claims.get("role") not in ("admin", "operator", "viewer"):
            raise ValueError("invalid role")
        return claims
    except Exception as exc:
        raise ValueError("Invalid or expired bearer token") from exc
