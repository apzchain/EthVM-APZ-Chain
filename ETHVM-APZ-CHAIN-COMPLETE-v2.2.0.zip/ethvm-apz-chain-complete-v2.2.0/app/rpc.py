"""Strict, read-only JSON-RPC integration for the upstream Geth execution client."""
import asyncio
import httpx
from app.config import settings

class RPCFailure(RuntimeError):
    pass

async def rpc(method: str, params: list | None = None):
    if not settings.rpc_url:
        raise RPCFailure("APZ_RPC_URL is not configured")
    payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params or []}
    try:
        async with httpx.AsyncClient(timeout=settings.rpc_timeout_seconds) as client:
            response = await client.post(settings.rpc_url, json=payload)
            response.raise_for_status()
            data = response.json()
    except (httpx.HTTPError, ValueError) as exc:
        raise RPCFailure("Execution client is unreachable or returned invalid JSON-RPC") from exc
    if not isinstance(data, dict) or data.get("jsonrpc") != "2.0":
        raise RPCFailure("Malformed JSON-RPC envelope")
    if data.get("error"):
        error = data["error"]
        message = error.get("message", "unknown RPC error") if isinstance(error, dict) else "unknown RPC error"
        raise RPCFailure(f"Execution client RPC error: {message}")
    if "result" not in data:
        raise RPCFailure("Malformed JSON-RPC response: result missing")
    return data["result"]

async def _hex_int(method: str) -> int:
    value = await rpc(method)
    if not isinstance(value, str) or not value.startswith("0x"):
        raise RPCFailure(f"Invalid hexadecimal quantity returned by {method}")
    return int(value, 16)

async def _network_id() -> int:
    value = await rpc("net_version")
    if not isinstance(value, str) or not value.isdecimal():
        raise RPCFailure("Invalid decimal network ID returned by net_version")
    return int(value, 10)

async def node_status():
    try:
        chain_id, network_id, block, genesis_block, syncing, peers, client_version, gas_price, txpool = await asyncio.gather(
            _hex_int("eth_chainId"), _network_id(), _hex_int("eth_blockNumber"),
            rpc("eth_getBlockByNumber", ["0x0", False]), rpc("eth_syncing"),
            _hex_int("net_peerCount"), rpc("web3_clientVersion"), _hex_int("eth_gasPrice"),
            rpc("txpool_status"),
        )
        genesis_hash = genesis_block.get("hash", "").lower() if isinstance(genesis_block, dict) else ""
        identity_checks_configured = (settings.expected_chain_id is not None
            and settings.expected_network_id is not None
            and bool(settings.expected_genesis_block_hash))
        identity_verified = bool(identity_checks_configured
            and chain_id == settings.expected_chain_id
            and network_id == settings.expected_network_id
            and genesis_hash == settings.expected_genesis_block_hash)
        return {
            "connected": True,
            "network": settings.network_name,
            "chain_id": chain_id,
            "network_id": network_id,
            "genesis_block_hash": genesis_hash or None,
            "latest_block": block,
            "syncing": syncing,
            "peer_count": peers,
            "client_role": "execution",
            "client_version": client_version,
            "gas_price_wei": str(gas_price),
            "txpool": {
                "pending": int(txpool.get("pending", "0x0"), 16),
                "queued": int(txpool.get("queued", "0x0"), 16),
            } if isinstance(txpool, dict) else {"pending": None, "queued": None},
            "network_identity_verified": identity_verified,
            "identity_checks_configured": identity_checks_configured,
            "note": ("Official network identity checks passed." if identity_verified else
                     "Network identity is unverified: configure official chain ID, network ID, and genesis block hash."),
        }
    except (RPCFailure, TypeError, ValueError, AttributeError) as exc:
        return {"connected": False, "network": settings.network_name,
                "client_role": "execution", "error": str(exc)}

async def readiness():
    status = await node_status()
    return {"ready": bool(status.get("connected")), "execution": status}

# The management API deliberately exposes only a small, read-only RPC allowlist.
READ_ONLY_METHODS = {
    "eth_chainId", "eth_blockNumber", "eth_syncing", "eth_gasPrice",
    "eth_getBlockByNumber", "eth_getBlockByHash", "eth_getTransactionByHash",
    "eth_getTransactionReceipt", "eth_getBalance", "eth_getCode", "eth_getStorageAt",
    "eth_call", "eth_estimateGas", "eth_getLogs", "net_version", "net_peerCount",
    "web3_clientVersion", "txpool_status",
}

async def read_rpc(method: str, params: list | None = None):
    if method not in READ_ONLY_METHODS:
        raise RPCFailure("RPC method is not in the management API read-only allowlist")
    return await rpc(method, params)
