import os
from pydantic import BaseModel, Field

class Settings(BaseModel):
    app_env: str = os.getenv("APP_ENV", "development")
    network_name: str = os.getenv("APZ_NETWORK_NAME", "APZ Local Devnet")
    rpc_url: str = os.getenv("APZ_RPC_URL", "")
    consensus_api_url: str = os.getenv("APZ_CONSENSUS_API_URL", "")
    expected_chain_id: int | None = int(os.environ["APZ_CHAIN_ID"]) if os.getenv("APZ_CHAIN_ID", "").isdigit() else None
    expected_network_id: int | None = int(os.environ["APZ_NETWORK_ID"]) if os.getenv("APZ_NETWORK_ID", "").isdigit() else None
    expected_genesis_block_hash: str = os.getenv("APZ_GENESIS_BLOCK_HASH", "").lower()
    rpc_timeout_seconds: float = Field(default=float(os.getenv("APZ_RPC_TIMEOUT_SECONDS", "5")), ge=0.5, le=60)
    admin_username: str = os.getenv("ADMIN_USERNAME", "admin")
    admin_password: str = os.getenv("ADMIN_PASSWORD", "")
    jwt_secret: str = os.getenv("JWT_SECRET", "")
    jwt_ttl_minutes: int = int(os.getenv("JWT_TTL_MINUTES", "60"))
    audit_log_path: str = os.getenv("AUDIT_LOG_PATH", "/data/audit.jsonl")
    cors_origins: list[str] = [x.strip() for x in os.getenv("CORS_ORIGINS", "http://localhost:8080").split(",") if x.strip()]

settings = Settings()
