package org.apz.ethvmmanager

import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Button
import android.view.ViewGroup
import android.graphics.Color
import android.content.Intent
import android.net.Uri

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("apz_manager", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val server = prefs.getString("server_url", "") ?: ""
        if (server.isBlank()) showServerSetup() else openDashboard(server)
    }

    private fun showServerSetup() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 60, 36, 36)
            setBackgroundColor(Color.rgb(11, 16, 32))
        }
        val input = EditText(this).apply {
            hint = "https://your-apz-server.example"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setText(prefs.getString("server_url", ""))
        }
        val save = Button(this).apply {
            text = "Connect to management server"
            setOnClickListener {
                val url = input.text.toString().trim().trimEnd('/')
                if (url.startsWith("https://") || url.startsWith("http://10.0.2.2") || url.startsWith("http://192.168.")) {
                    prefs.edit().putString("server_url", url).apply()
                    openDashboard(url)
                } else {
                    input.error = "Use HTTPS for remote servers"
                }
            }
        }
        layout.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        layout.addView(save)
        setContentView(layout)
    }

    private fun openDashboard(server: String) {
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                if (url.startsWith(server)) return false
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                return true
            }
        }
        web.webChromeClient = WebChromeClient()
        setContentView(web)
        web.loadUrl(server)
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
