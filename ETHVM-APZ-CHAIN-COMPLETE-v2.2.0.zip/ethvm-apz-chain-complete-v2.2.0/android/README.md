# Android management client
- Android 8.0+ minimum (API 26); tested target configuration Android 15/API 35.
- Open this folder in Android Studio with JDK 17.
- Sync Gradle, then Build > Build APK(s).
- The app connects to the server-hosted management dashboard. It does not run a blockchain node.
- Remote server URLs must use HTTPS. The manifest's cleartext allowance exists for local LAN testing;
  remove it and enforce HTTPS before publishing to Google Play.
- No signing keystore is included. Create and protect your own release signing key.
