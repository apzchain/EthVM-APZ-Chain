$ErrorActionPreference = "Stop"
if (-not (Test-Path ".env")) { throw "Missing .env. Run .\windows\install.ps1 first." }
docker compose up --build -d
Write-Host "Dashboard: http://localhost:8080"
Write-Host "API docs:  http://localhost:8080/docs"
