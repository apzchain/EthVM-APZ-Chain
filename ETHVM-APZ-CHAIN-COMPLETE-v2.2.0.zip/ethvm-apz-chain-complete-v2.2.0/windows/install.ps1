$ErrorActionPreference = "Stop"
Write-Host "EthVM-APZ 2.1 - prerequisite check"
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
  throw "Docker CLI not found. Install Docker Desktop, start it, and rerun this script."
}
docker compose version
if (-not (Test-Path ".env")) {
  Copy-Item ".env.example" ".env"
  Write-Warning "Created .env. Edit ADMIN_PASSWORD and JWT_SECRET before continuing."
}
Write-Host "Prerequisites detected. Review .env, then run .\windows\start.ps1"
