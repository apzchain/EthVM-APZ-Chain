#!/usr/bin/env python3
"""Create a private Engine API JWT secret; does not create validator keys."""
import os
import secrets
from pathlib import Path

root = Path(__file__).resolve().parents[1]
target = root / os.getenv("APZ_JWT_FILE", "secrets/jwt.hex")
target.parent.mkdir(parents=True, exist_ok=True)
if target.exists():
    raise SystemExit(f"Refusing to overwrite existing secret: {target}")
target.write_text(secrets.token_hex(32), encoding="ascii")
os.chmod(target, 0o600)
print(f"Created Engine API JWT secret: {target}")
print("Copy this same file securely to the consensus client. Never commit it.")
