#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
python3 scripts/validate_apz_network.py
docker compose --env-file .env -f docker-compose.apz.yml up -d --build
docker compose --env-file .env -f docker-compose.apz.yml ps
