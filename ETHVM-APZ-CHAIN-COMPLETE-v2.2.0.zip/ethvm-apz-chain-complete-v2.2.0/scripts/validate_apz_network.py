#!/usr/bin/env python3
"""Fail-closed preflight for an APZ execution + Lighthouse deployment.

This validates operator-supplied network artifacts. It never creates genesis,
chain IDs, fork parameters, bootnodes, or validator keys.
"""
from __future__ import annotations
import hashlib
import json
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GENESIS = ROOT / os.getenv("APZ_GENESIS_PATH", "network/apz/genesis.json")
LIGHTHOUSE_DIR = ROOT / os.getenv("APZ_LIGHTHOUSE_CONFIG_DIR", "network/apz/lighthouse")
JWT_FILE = ROOT / os.getenv("APZ_JWT_FILE", "secrets/jwt.hex")

def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(2)

def main() -> None:
    required = ["APZ_CHAIN_ID", "APZ_NETWORK_ID", "APZ_GENESIS_SHA256", "APZ_GENESIS_BLOCK_HASH", "APZ_CONSENSUS_GENESIS_SHA256", "APZ_CONSENSUS_TYPE"]
    missing = [name for name in required if not os.getenv(name, "").strip()]
    if missing:
        fail("Missing required official network values: " + ", ".join(missing))
    try:
        chain_id = int(os.environ["APZ_CHAIN_ID"], 10)
        network_id = int(os.environ["APZ_NETWORK_ID"], 10)
    except ValueError:
        fail("APZ_CHAIN_ID and APZ_NETWORK_ID must be decimal integers")
    if chain_id <= 0 or network_id <= 0:
        fail("APZ_CHAIN_ID and APZ_NETWORK_ID must be positive")
    if not GENESIS.is_file():
        fail(f"Official Geth genesis JSON not found: {GENESIS}")
    raw = GENESIS.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    expected = os.environ["APZ_GENESIS_SHA256"].strip().lower().removeprefix("0x")
    expected_block_hash = os.environ["APZ_GENESIS_BLOCK_HASH"].strip().lower()
    if not re.fullmatch(r"0x[0-9a-f]{64}", expected_block_hash):
        fail("APZ_GENESIS_BLOCK_HASH must be the official 32-byte genesis block hash (0x + 64 hex chars)")
    if not re.fullmatch(r"[0-9a-f]{64}", expected):
        fail("APZ_GENESIS_SHA256 must be a 64-character SHA-256 digest")
    if digest != expected:
        fail(f"Genesis SHA-256 mismatch: computed {digest}")
    try:
        genesis = json.loads(raw)
    except json.JSONDecodeError as exc:
        fail(f"Genesis JSON is invalid: {exc}")
    config = genesis.get("config")
    if not isinstance(config, dict) or config.get("chainId") != chain_id:
        fail("Genesis config.chainId does not exactly match APZ_CHAIN_ID")
    for key in ("nonce", "timestamp", "extraData", "gasLimit", "difficulty", "alloc"):
        if key not in genesis:
            fail(f"Genesis is missing required field: {key}")
    if not isinstance(genesis.get("alloc"), dict):
        fail("Genesis alloc must be a JSON object")
    if not LIGHTHOUSE_DIR.is_dir():
        fail(f"Lighthouse custom-network directory not found: {LIGHTHOUSE_DIR}")
    for name in ("config.yaml", "genesis.ssz", "boot_enr.yaml"):
        artifact = LIGHTHOUSE_DIR / name
        if not artifact.is_file() or artifact.stat().st_size == 0:
            fail(f"Lighthouse network artifact missing or empty: {artifact}")
    if os.environ["APZ_CONSENSUS_TYPE"].strip() != "ethereum-pos-engine-api":
        fail("This deployment profile supports only the explicitly confirmed ethereum-pos-engine-api consensus type")
    consensus_digest = hashlib.sha256((LIGHTHOUSE_DIR / "genesis.ssz").read_bytes()).hexdigest()
    expected_consensus = os.environ["APZ_CONSENSUS_GENESIS_SHA256"].strip().lower().removeprefix("0x")
    if not re.fullmatch(r"[0-9a-f]{64}", expected_consensus) or consensus_digest != expected_consensus:
        fail(f"Consensus genesis SSZ SHA-256 mismatch: computed {consensus_digest}")
    if not JWT_FILE.is_file():
        fail(f"Engine API JWT secret missing: {JWT_FILE}; run scripts/create_engine_jwt.py")
    jwt = JWT_FILE.read_text(encoding="ascii").strip()
    if not re.fullmatch(r"[0-9a-fA-F]{64}", jwt):
        fail("Engine API JWT secret must contain exactly 32 bytes as 64 hex characters")
    print("APZ network preflight: PASS")
    print(f"chain_id={chain_id}")
    print(f"network_id={network_id}")
    print(f"genesis_file_sha256={digest}")
    print(f"expected_genesis_block_hash={expected_block_hash}")
    print(f"consensus_genesis_ssz_sha256={consensus_digest}")
    print("consensus_client=Lighthouse (Ethereum PoS-compatible configuration required)")
    print("validator_keys=not generated or imported by this tool")

if __name__ == "__main__":
    main()
