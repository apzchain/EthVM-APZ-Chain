import os
os.environ.setdefault("ADMIN_PASSWORD", "test-password")
os.environ.setdefault("JWT_SECRET", "test-secret-that-is-at-least-32-characters-long")
os.environ.setdefault("AUDIT_LOG_PATH", "/tmp/ethvm-apz-test-audit.jsonl")

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"

def test_dashboard_requires_auth():
    assert client.get("/api/v1/dashboard").status_code == 401

def test_login_and_dashboard():
    r = client.post("/api/v1/auth/login", json={"username":"admin","password":"test-password"})
    assert r.status_code == 200
    token = r.json()["access_token"]
    d = client.get("/api/v1/dashboard", headers={"Authorization":f"Bearer {token}"})
    assert d.status_code == 200
    assert d.json()["validator"]["status"] == "not_configured"

def test_invalid_login():
    r = client.post("/api/v1/auth/login", json={"username":"admin","password":"wrong"})
    assert r.status_code == 401
