# EthVM-APZ Chain Complete 2.0

Open-source EVM node operations and administration platform.

## What this release actually provides
- A real upstream Geth execution client in an isolated **local development network** (`--dev`).
- FastAPI management API with password hashing, signed bearer tokens, role checks, audit events,
  RPC health/block-height inspection, and an authenticated node overview.
- A responsive Persian/English-capable RTL web administration panel.
- Windows PowerShell setup/start/stop scripts.
- Android management client source project (Kotlin + WebView), minSdk 26 / targetSdk 35.
- CI workflow, API tests, dependency/security scanning workflow, and operational docs.

## Critical network/validator distinction
This package boots Geth in ephemeral development mode. Geth is an EVM **execution client**;
it does not create an APZ Mainnet, configure a consensus layer, or make a node a PoS validator.
A production PoS network needs matching execution + consensus clients, chain genesis,
fork schedule, bootnodes, JWT secret shared between clients, validator keys and deposits,
and independently verified network parameters. Those values are intentionally not fabricated.

The API reports validator state as `not_configured` unless a future, verified consensus
integration is configured. No private key is generated, stored, imported, or exposed here.

## Requirements
- Docker Engine and Docker Compose v2
- For local Python development: Python 3.11+
- For Android: Android Studio (Koala or newer), JDK 17, Android SDK 35

## Quick start (Linux/macOS)
```bash
cp .env.example .env
# Set ADMIN_PASSWORD to a long unique password.
docker compose up --build -d
```
Open `http://localhost:8080`. Default username is `admin`; set the password in `.env`.
The sample `.env.example` contains a development-only password. Change it before use.

## Windows
Run PowerShell as a normal user:
```powershell
Copy-Item .env.example .env
notepad .env
.\windows\install.ps1
.\windows\start.ps1
```
Docker Desktop must be installed and running. Scripts do not silently install software.

## Local Python development
```bash
python -m venv .venv
# Windows: .venv\Scripts\Activate.ps1
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
$env:APZ_RPC_URL="http://127.0.0.1:8545"
$env:ADMIN_PASSWORD="change-this-password"
uvicorn app.main:app --host 127.0.0.1 --port 8080
```

## Android management client
Open `android/` in Android Studio, allow Gradle sync, then Build > Build APK(s).
Configure the management server URL in the app. The app is a remote management client;
the EVM node runs on a server or workstation, not inside the Android app.
Use HTTPS for remote access. Cleartext HTTP is permitted only for local development.

## API
- `POST /api/v1/auth/login`
- `GET /api/v1/auth/me`
- `GET /api/v1/dashboard`
- `GET /api/v1/node/status`
- `GET /api/v1/validator/status`
- `GET /api/v1/audit/recent` (admin role)
- `GET /health`
Interactive API docs: `/docs`.

## Security
- Change all sample credentials and secrets before deployment.
- Bind RPC to loopback only. Do not expose port 8545 to the public internet.
- Do not mount the Docker socket into the API container.
- Put the API behind TLS and a reverse proxy for remote access.
- Use a secret manager for production secrets.
- The included audit log is an operational JSONL log, not a tamper-proof ledger.
- Review the threat model in `documentation/security/THREAT_MODEL.md`.

## Tests
```bash
pip install -r requirements-dev.txt
pytest -q
```

## License
MIT. See `LICENSE`.
