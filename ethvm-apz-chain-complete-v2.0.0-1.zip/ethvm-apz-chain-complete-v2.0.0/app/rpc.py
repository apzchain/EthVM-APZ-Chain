import httpx
from app.config import settings

class RPCFailure(RuntimeError): pass

async def rpc(method: str, params: list | None = None):
    if not settings.rpc_url:
        raise RPCFailure("APZ_RPC_URL is not configured")
    payload = {"jsonrpc":"2.0","id":1,"method":method,"params":params or []}
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.post(settings.rpc_url, json=payload)
            response.raise_for_status()
            data = response.json()
    except (httpx.HTTPError, ValueError) as exc:
        raise RPCFailure("Execution client is unreachable or returned invalid JSON-RPC") from exc
    if data.get("error"):
        raise RPCFailure("Execution client JSON-RPC error")
    if "result" not in data:
        raise RPCFailure("Malformed JSON-RPC response")
    return data["result"]

async def node_status():
    try:
        chain_id, block, syncing, peers = await _multi()
        return {"connected": True, "network": settings.network_name,
                "chain_id": int(chain_id, 16), "latest_block": int(block, 16),
                "syncing": syncing, "peer_count": int(peers, 16),
                "client_role": "execution"}
    except RPCFailure as exc:
        return {"connected": False, "network": settings.network_name, "error": str(exc)}

async def _multi():
    return (await rpc("eth_chainId"), await rpc("eth_blockNumber"),
            await rpc("eth_syncing"), await rpc("net_peerCount"))
