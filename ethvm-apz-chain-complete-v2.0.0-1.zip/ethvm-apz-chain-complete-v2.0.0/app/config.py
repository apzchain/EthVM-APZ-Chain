import os
from pydantic import BaseModel

class Settings(BaseModel):
    app_env: str = os.getenv("APP_ENV", "development")
    network_name: str = os.getenv("APZ_NETWORK_NAME", "APZ Chain")
    rpc_url: str = os.getenv("APZ_RPC_URL", "")
    admin_username: str = os.getenv("ADMIN_USERNAME", "admin")
    admin_password: str = os.getenv("ADMIN_PASSWORD", "")
    jwt_secret: str = os.getenv("JWT_SECRET", "")
    jwt_ttl_minutes: int = int(os.getenv("JWT_TTL_MINUTES", "60"))
    audit_log_path: str = os.getenv("AUDIT_LOG_PATH", "/data/audit.jsonl")
    cors_origins: list[str] = [x.strip() for x in os.getenv("CORS_ORIGINS", "http://localhost:8080").split(",") if x.strip()]

settings = Settings()
