from fastapi import FastAPI, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from pathlib import Path
from app.config import settings
from app.security import password_hash, password_verify, issue_token, verify_token
from app.audit import audit, recent
from app.rpc import node_status

app = FastAPI(title="EthVM-APZ Management API", version="2.0.0")
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins,
                   allow_credentials=False, allow_methods=["GET","POST"],
                   allow_headers=["Authorization","Content-Type"])
bearer = HTTPBearer(auto_error=False)

# A single bootstrap admin is provided for this baseline. For production, replace
# with an external identity provider and persistent user/role database.
_BOOTSTRAP_HASH = password_hash(settings.admin_password) if settings.admin_password else ""

class Login(BaseModel):
    username: str = Field(min_length=1, max_length=80)
    password: str = Field(min_length=1, max_length=256)

def current_user(creds: HTTPAuthorizationCredentials | None = Depends(bearer)):
    if not creds:
        raise HTTPException(401, "Bearer token required")
    try:
        return verify_token(creds.credentials)
    except ValueError:
        raise HTTPException(401, "Invalid or expired token")

def require_admin(user=Depends(current_user)):
    if user["role"] != "admin":
        raise HTTPException(403, "Administrator role required")
    return user

@app.get("/health")
async def health():
    return {"status":"ok","version":"2.0.0"}

@app.post("/api/v1/auth/login")
async def login(body: Login):
    valid = (settings.admin_password and body.username == settings.admin_username
             and password_verify(body.password, _BOOTSTRAP_HASH))
    if not valid:
        audit("login_failed", body.username)
        raise HTTPException(401, "Invalid username or password")
    token = issue_token(body.username, "admin")
    audit("login_success", body.username)
    return {"access_token":token,"token_type":"bearer","expires_in":settings.jwt_ttl_minutes*60}

@app.get("/api/v1/auth/me")
async def me(user=Depends(current_user)):
    return {"username":user["sub"],"role":user["role"]}

@app.get("/api/v1/dashboard")
async def dashboard(user=Depends(current_user)):
    node = await node_status()
    return {"network":settings.network_name,"node":node,
            "validator":{"status":"not_configured",
                         "reason":"No verified APZ consensus client or validator configuration is supplied."},
            "authenticated_user":user["sub"]}

@app.get("/api/v1/node/status")
async def get_node_status(user=Depends(current_user)):
    return await node_status()

@app.get("/api/v1/validator/status")
async def validator_status(user=Depends(current_user)):
    return {"status":"not_configured","client":"none",
            "message":"Execution client status is not validator consensus status."}

@app.get("/api/v1/audit/recent")
async def audit_recent(user=Depends(require_admin)):
    return {"events":recent()}

WEB = Path(__file__).resolve().parents[1] / "web"
app.mount("/assets", StaticFiles(directory=WEB), name="assets")

@app.get("/")
async def index():
    return FileResponse(WEB / "index.html")
