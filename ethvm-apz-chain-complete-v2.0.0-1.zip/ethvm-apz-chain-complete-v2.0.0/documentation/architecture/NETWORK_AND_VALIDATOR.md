# Execution node and validator architecture

Geth is the execution client in this package. The bundled Compose profile runs `geth --dev`
to provide a reproducible local EVM development chain. It is intentionally not represented
as APZ Mainnet.

For a production PoS chain, pair an execution client with a compatible consensus client.
The two clients must share an authenticated Engine API JWT secret and identical network
configuration. Validator duties belong to the consensus client and require properly
generated validator keys and protocol-specific deposits/registration. Keep signing keys
offline or in an approved signer/HSM where supported.

Before adding APZ Mainnet support, obtain and verify:
- authoritative chain ID and genesis file/hash
- execution client version and chain configuration/fork schedule
- consensus client, genesis state, network name and fork schedule
- bootnodes, checkpoint sync endpoints and peer policy
- Engine API endpoint and JWT secret provisioning procedure
- validator activation/deposit rules and slashing protection requirements
- official RPC/explorer endpoints and upgrade governance process

Do not copy a development chain ID or temporary dev account into production.
