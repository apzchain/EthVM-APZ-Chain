# Operations runbook

`docker compose ps` — service state
`docker compose logs -f geth api` — logs
`docker compose restart api` — restart API
`docker compose down` — stop containers (named volumes remain)
`docker compose down -v` — destructive: removes chain and API data volumes

The dev chain is ephemeral in nature and must not be used to hold valuable assets.
Back up the Docker volumes using a tested host-level backup procedure.
